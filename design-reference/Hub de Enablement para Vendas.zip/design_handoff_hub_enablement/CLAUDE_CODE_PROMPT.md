# Prompt e plano de build — Hub de Enablement Morada

Este arquivo é feito para ser **colado no Claude Code** (ou lido por ele) na raiz de um repositório novo. Ele traz: decisão de stack, schema, auth, rotas, critérios de aceite por tela e um plano em blocos para ter a plataforma rodando em um dia.

Leia junto com `README.md` (spec visual detalhada, tokens, medidas) e abra `Hub de Enablement.dc.html` no navegador para ver o protótipo funcionando.

---

## 0. Prompt para colar no Claude Code

> Você vai construir o **Hub de Enablement da Morada.ai**: uma plataforma interna de conteúdo para os times de Vendas, CS, Onboarding e Marketing. O objetivo #1 é manter o time atualizado nas novidades do produto; além disso o hub organiza trilhas de aprendizado por produto/módulo, guarda a biblioteca de materiais (decks, apresentações de release, one-pagers, templates) e registra progresso e avaliação das aulas.
>
> **Stack obrigatória:** Next.js (App Router, TypeScript) + Tailwind CSS 4 + `@morada-ai/niemeyer` (nosso design system, shadcn-based) + `@tabler/icons-react` + Supabase (Auth, Postgres, Storage) + deploy na Vercel. Fontes Outfit (títulos) e Lato (corpo) via `next/font`.
>
> **Login:** Google OAuth via Supabase Auth, restrito ao domínio `morada.ai`. Passe `hd=morada.ai` no authorize e **valide o domínio também no servidor** (callback + middleware); e-mail de outro domínio é recusado com mensagem clara e sessão destruída. Sem cadastro, sem senha, sem convite manual.
>
> **Idioma:** toda a UI em **pt-BR, sentence case**, tom operacional e direto ("você"). Código, commits e comentários em inglês. Nunca use emoji na UI.
>
> **Visual:** siga o design system Niemeyer à risca — azul `#0073ff`, neutros frios, cards brancos `rounded-xl` com borda `neutral-200` e `shadow-xs`, tabelas com header `bg-primary/[0.06]` e `<th>` sentence case, foco visível de 3px, radii 8/12/16. A especificação de cada tela, com medidas e copy, está em `README.md`. O arquivo `Hub de Enablement.dc.html` é **referência de design**, não código de produção: recrie as telas com os componentes do Niemeyer (`Card`, `Button`, `Badge`, `Avatar`, `Progress`, `Tabs`, `DataTable`, `KpiCard`, `AppShell`, `SidebarShell`, `TopBarShell`, `EmptyState`, `Dialog`, `FileUploader`, `Wizard`) em vez de copiar o HTML inline.
>
> **Telas:** (1) Login, (2) Home com novidades + "continue de onde parou" + materiais recentes, (3) Trilhas com filtros, (4) Detalhe da trilha com sequência de aulas, (5) Materiais navegando **produto → feature → arquivos** com breadcrumb e busca global, (6) Meu progresso com KPIs, progresso por módulo, certificados e ofensiva, (7) Modal de avaliação ao concluir uma aula, (8) Área "Gerenciar" (só admin) para subir material/aula e ver o feedback recebido.
>
> **Escopo do dia 1:** tudo acima funcionando com dados reais no banco, upload real no Storage e progresso persistido por usuário. Não construa: editor de quiz, player próprio de vídeo, certificados em PDF, notificações por e-mail, versionamento de arquivo. Deixe TODOs claros.
>
> Trabalhe em blocos, commitando a cada bloco (ver "Plano de build" abaixo). Ao final, rode `pnpm build`, corrija o que quebrar e escreva no README do repo como rodar local e como configurar as variáveis de ambiente.

---

## 1. Stack e decisões

| Decisão | Escolha | Por quê |
|---|---|---|
| Framework | **Next.js App Router + TS** | é o stack de produção da Morada; Server Components deixam a maior parte das telas sem client JS. |
| UI | **Tailwind 4 + `@morada-ai/niemeyer`** | design system oficial; não recriar primitivos. |
| Ícones | **`@tabler/icons-react`** | único set permitido pelo lint do Niemeyer. |
| Auth | **Supabase Auth (Google)** | SSO Google pronto, sessão em cookie, RLS integrada ao Postgres. |
| Banco | **Supabase Postgres** | RLS por usuário resolve progresso/feedback sem backend próprio. |
| Arquivos | **Supabase Storage** (bucket privado + signed URLs) | upload direto do browser, sem servidor de mídia. |
| Hospedagem | **Vercel** | deploy em minutos, preview por PR. |
| Estado de servidor | **Server Actions + revalidatePath** | menos código que uma API REST; sem client state manager. |

Alternativa aceitável se a Morada já tiver infra: trocar Supabase por Postgres gerenciado + NextAuth (Google Provider com `hd`) + S3. Não misture as duas.

### Variáveis de ambiente

```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=        # só em server actions de admin
ALLOWED_EMAIL_DOMAIN=morada.ai
SLACK_WEBHOOK_URL=                # opcional: aviso de publicação
```

### Estrutura de pastas

```
app/
  (auth)/login/page.tsx
  (app)/layout.tsx                # AppShell: sidebar + top bar (server)
  (app)/page.tsx                  # Home
  (app)/trilhas/page.tsx
  (app)/trilhas/[trilha]/page.tsx
  (app)/materiais/page.tsx                        # nível produto
  (app)/materiais/[produto]/page.tsx              # nível feature
  (app)/materiais/[produto]/[feature]/page.tsx    # nível arquivo
  (app)/progresso/page.tsx
  (app)/gerenciar/page.tsx        # admin only
  auth/callback/route.ts
lib/supabase/{server,client,middleware}.ts
lib/auth.ts                       # requireUser(), requireAdmin(), assertDomain()
lib/queries/*.ts                  # catálogo, progresso, materiais, feedback
components/                       # composições de tela sobre o Niemeyer
middleware.ts                      # sessão + gate de domínio + gate de admin
supabase/migrations/0001_init.sql
```

---

## 2. Schema (Postgres / Supabase)

```sql
-- perfis, espelhando auth.users
create table profiles (
  id uuid primary key references auth.users on delete cascade,
  email text not null unique,
  full_name text,
  avatar_url text,
  team text,                                  -- 'vendas' | 'cs' | 'onboarding' | 'marketing' | 'outro'
  role text not null default 'member',        -- 'member' | 'admin'
  created_at timestamptz not null default now()
);

-- catálogo: produto > feature (pasta de materiais)
create table products (
  id text primary key,                        -- 'vendas' | 'relacionamento' | 'institucional'
  name text not null, accent text not null, description text, position int not null default 0
);
create table features (
  id text primary key,                        -- 'vendas:filas'
  product_id text not null references products on delete cascade,
  name text not null, description text, position int not null default 0
);

-- biblioteca de materiais
create table materials (
  id uuid primary key default gen_random_uuid(),
  feature_id text not null references features on delete cascade,
  title text not null, description text,
  ext text not null,                          -- 'PPTX' | 'PDF' | 'DOCX' | 'XLSX' | 'MP4' | 'LINK'
  format text not null,                       -- 'Apresentação' | 'PDF' | 'Documento' | 'Planilha' | 'Vídeo' | 'Notion' | 'Drive'
  storage_path text,                          -- arquivo no bucket
  external_url text,                          -- ou link Drive/Notion
  status text not null default 'published',   -- 'draft' | 'published'
  is_highlight boolean not null default true, -- aparece em Novidades
  created_by uuid references profiles,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (storage_path is not null or external_url is not null)
);

-- trilhas e aulas
create table tracks (
  id text primary key,                        -- 'v1'
  product_id text not null references products,
  title text not null, description text,
  level text not null,                        -- 'Essencial' | 'Intermediário' | 'Avançado'
  audience text, owner_id uuid references profiles,
  is_required boolean not null default false,
  position int not null default 0,
  updated_at timestamptz not null default now()
);
create table lessons (
  id uuid primary key default gen_random_uuid(),
  track_id text not null references tracks on delete cascade,
  position int not null,
  title text not null,
  kind text not null,                         -- 'video' | 'artigo' | 'deck' | 'quiz' | 'template' | 'link'
  duration_min int not null default 0,
  source_label text,                          -- 'Gravação interna', 'Notion', '8 perguntas'
  storage_path text, external_url text,
  published_at timestamptz not null default now(),
  unique (track_id, position)
);

-- progresso e avaliação
create table lesson_progress (
  user_id uuid not null references profiles on delete cascade,
  lesson_id uuid not null references lessons on delete cascade,
  completed_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);
create table lesson_feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references profiles on delete cascade,
  lesson_id uuid not null references lessons on delete cascade,
  stars smallint not null check (stars between 1 and 5),
  tags text[] not null default '{}',
  comment text,
  created_at timestamptz not null default now(),
  unique (user_id, lesson_id)
);
create table material_events (                -- telemetria de uso
  id bigserial primary key,
  user_id uuid references profiles,
  material_id uuid references materials on delete cascade,
  kind text not null,                         -- 'open' | 'download'
  created_at timestamptz not null default now()
);

create view lesson_ratings as
  select lesson_id, round(avg(stars)::numeric, 1) as avg_stars, count(*) as ratings_count
  from lesson_feedback group by lesson_id;
```

### RLS (essencial)

```sql
alter table profiles, lesson_progress, lesson_feedback, materials, tracks, lessons,
      products, features, material_events enable row level security;

-- leitura: qualquer usuário autenticado do domínio (o gate de domínio é no login)
create policy read_catalog on materials for select to authenticated
  using (status = 'published' or exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin'));
-- idem select liberado em products/features/tracks/lessons para authenticated

-- progresso e feedback: cada um só vê e escreve o seu
create policy own_progress on lesson_progress for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy own_feedback on lesson_feedback for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
-- admin lê todo o feedback
create policy admin_reads_feedback on lesson_feedback for select to authenticated
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin'));

-- escrita de catálogo/materiais: só admin
create policy admin_writes_materials on materials for insert, update, delete to authenticated
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin'));
```

Trigger `on auth.users insert` → cria `profiles` com `role='member'`; os primeiros admins são setados na mão via SQL.

Storage: bucket **privado** `hub-materials`, caminho `{product}/{feature}/{uuid}-{slug}.{ext}`. Download sempre por **signed URL de 60s** gerada em server action; nunca URL pública.

---

## 3. Auth — Google restrito a morada.ai

1. Google Cloud: OAuth Client (Web), redirect `https://<projeto>.supabase.co/auth/v1/callback`.
2. Supabase → Auth → Providers → Google: client id/secret. Em Auth → URL config, adicione o domínio da Vercel.
3. No client: `signInWithOAuth({ provider: 'google', options: { queryParams: { hd: 'morada.ai', prompt: 'select_account' }, redirectTo: `${origin}/auth/callback` } })`.
4. **`hd` é dica, não segurança.** Em `auth/callback/route.ts` e no `middleware.ts`: se `user.email` não terminar em `@${ALLOWED_EMAIL_DOMAIN}` → `signOut()` + redirect `/login?erro=dominio`.
5. Login mostra o erro: "Use sua conta @morada.ai. Contas pessoais não têm acesso ao hub."
6. `middleware.ts` protege tudo fora de `/login` e `/auth`; `/gerenciar` exige `role = 'admin'` (404 para os outros, não 403 — não vaze a existência da área).

---

## 4. Comportamento por tela (critérios de aceite)

**Login** — Sem sessão, qualquer rota redireciona para `/login`. Um único botão "Entrar com Google". Conta fora do domínio é recusada com mensagem. Com sessão válida, `/login` redireciona para `/`.

**Home** — Saudação por horário + nome do usuário. Bloco "Novidades no hub": aulas e materiais com `published_at`/`updated_at` nos últimos 30 dias, mais novo primeiro, selo NOVO até 7 dias; clicar abre o item. "Continue de onde parou": até 3 trilhas com progresso entre 1 e 99%, mostrando a próxima aula pendente. "Materiais recentes": 3 arquivos novos, com deep link para a pasta da feature. Números do bloco "Sua semana" vêm do banco, nunca hardcoded.

**Trilhas** — Filtro por produto e por status (em andamento / concluídas / não iniciadas) + busca; filtros vivem na URL e sobrevivem ao reload. Card mostra progresso real. Zero resultados → EmptyState com "Limpar filtros".

**Detalhe da trilha** — Aulas em ordem, cada uma com número, tipo, duração, fonte e média de avaliação. Abrir a aula registra `open`; concluir grava `lesson_progress` e **abre o modal de avaliação**. A barra de progresso, o CTA ("Começar aula N" / "Trilha concluída") e o certificado reagem na hora. Marcar/desmarcar é idempotente.

**Modal de avaliação (fim de aula)** — Dispara ao concluir uma aula, uma única vez por usuário/aula (se já avaliou, não pergunta de novo). Estrelas 1–5 + tags multi-seleção (Clara e direta · Faltou exemplo prático · Longa demais · Conteúdo desatualizado · Vou usar hoje) + comentário opcional. "Pular" fecha e **não** volta a perguntar naquela sessão. "Enviar" grava `lesson_feedback` e mostra toast "Avaliação enviada. Obrigado!". Fechável por Esc e clique fora; foco preso no dialog (use o `Dialog` do Niemeyer).

**Materiais** — Três níveis navegáveis (produto → feature → arquivos) com breadcrumb clicável e botão Voltar. Selo NOVO sobe: arquivo novo marca a feature e o produto. Busca no topo vira lista plana com a coluna "Onde está". "Abrir" usa signed URL; "Baixar" só aparece para arquivo (não para LINK). Todo open/download grava `material_events`.

**Meu progresso** — KPIs (aulas concluídas, trilhas concluídas, ofensiva, tempo de estudo) calculados no servidor. Progresso por produto. Certificado listado quando a trilha chega a 100%. Ofensiva = dias consecutivos com ao menos 1 conclusão, calculada dos timestamps (fuso `America/Sao_Paulo`), não incrementada no client.

**Gerenciar (admin)** — Formulário único: tipo (Material | Aula de trilha) → produto → pasta da feature ou trilha → título → descrição → upload (drag & drop, PPTX/PDF/DOCX/XLSX/MP4 até 200 MB) **ou** link externo (Drive/Notion/YouTube/Loom) → toggles: publicar em Novidades, avisar no Slack, marcar como obrigatório. Ações: "Publicar no hub" e "Salvar rascunho". Upload vai direto para o Storage com progresso e mensagem de erro real (tipo/tamanho inválido). Publicar revalida a home e devolve toast. Painel lateral: últimos publicados (com status e autor) e feed de feedback das aulas (nota, aula, comentário, time, quando) — é isso que diz ao enablement o que atualizar.

---

## 5. Plano de build (1 dia, commit por bloco)

1. **Setup (45 min)** — `create-next-app` TS, Tailwind 4 + preset Niemeyer, fontes, `@tabler/icons-react`, projeto Supabase, migração `0001_init.sql`, seed do catálogo (produtos, features, trilhas, aulas — use os dados do protótipo como seed inicial).
2. **Auth + shell (1h)** — Google provider, callback com gate de domínio, middleware, `profiles` trigger, `AppShell` com sidebar (Home · Trilhas · Materiais · Gerenciar · Meu progresso) e top bar com busca, ofensiva, avatar e sair.
3. **Home + Trilhas + Detalhe (2h)** — queries de catálogo e progresso, server actions `completeLesson`/`uncompleteLesson`, cards e barras de progresso.
4. **Modal de avaliação (45 min)** — `Dialog` do Niemeyer, action `submitFeedback`, view `lesson_ratings` alimentando a média nas aulas.
5. **Materiais (1h30)** — três rotas hierárquicas, breadcrumb, busca global, signed URLs, telemetria.
6. **Gerenciar (1h30)** — upload para o Storage, actions `publishMaterial`/`publishLesson`/`saveDraft`, feed de feedback, gate de admin, webhook do Slack (opcional).
7. **Meu progresso (45 min)** — KPIs, progresso por produto, certificados, ofensiva.
8. **Acabamento (1h)** — estados vazios, loading/skeleton, foco e teclado, responsivo (≥900px 2 colunas, sidebar vira rail), `pnpm build`, deploy na Vercel, seed dos admins.

---

## 6. Checklist de QA antes de liberar para o time

- [ ] Conta fora de `@morada.ai` não entra e vê mensagem clara.
- [ ] Recarregar mantém sessão, filtros (URL) e progresso (banco).
- [ ] Concluir aula: progresso, KPI, ofensiva e certificado atualizam sem F5.
- [ ] Modal de avaliação não reaparece para aula já avaliada.
- [ ] `/gerenciar` responde 404 para quem não é admin.
- [ ] Upload de 150 MB conclui; arquivo inválido dá erro compreensível.
- [ ] Nenhum arquivo do bucket é acessível sem signed URL.
- [ ] Toda a UI em pt-BR sentence case, sem emoji, sem texto em inglês.
- [ ] Lighthouse a11y ≥ 95; navegação por teclado em cards, tabela e modal.

## 7. O que NÃO fazer no dia 1

Editor/execução de quiz, player de vídeo próprio, certificado em PDF, versionamento de material, notificação por e-mail, comentários entre colegas, dark mode, app mobile. Tudo isso é v2 — deixe TODO no código apontando para este arquivo.
